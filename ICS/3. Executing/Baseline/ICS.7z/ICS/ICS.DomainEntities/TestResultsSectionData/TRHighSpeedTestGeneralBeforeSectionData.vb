''' <summary>
''' Test Results General test before Section Data - to be used in populating of UI controls
''' </summary>
''' <remarks>NOTE: Member names must match control IDs in a UI form</remarks>
Public Class TRHighSpeedTestGeneralBeforeSectionData

    Public HighSpeedTestMachine As String = String.Empty
    Public HighSpeedDiameterTestDrum As String = String.Empty
    Public HighSpeedTestRim As String = String.Empty
    Public HighSpeedDateOfManufacture As String = String.Empty
    Public HighSpeedTestWheelPosition As String = String.Empty
    Public HighSpeedTireSerialNumber As String = String.Empty
    Public HighSpeedDOTCode As String = String.Empty
    Public HighSpeedPreconditioningTime As String = String.Empty
    Public HighSpeedPreconditioningTemperature As String = String.Empty
    Public HighSpeedInflationPressure As String = String.Empty
    Public HighSpeedInflationPressureAdjusted As String = String.Empty
    Public HighSpeedCircumferenceBefore As String = String.Empty
    Public HighSpeedOuterDiameterBefore As String = String.Empty
    Public HighSpeedTestInflationPressureBefore As String = String.Empty

End Class
