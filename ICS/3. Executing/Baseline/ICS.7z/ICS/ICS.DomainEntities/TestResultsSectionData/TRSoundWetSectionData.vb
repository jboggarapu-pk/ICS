''' <summary>
''' Test Results Sound WetGrip Section Data - to be used in populating of UI controls
''' </summary>
''' <remarks>NOTE: Member names must match control IDs in a UI form</remarks>
Public Class TRSoundWetSectionData

    Public SWTestReportNo As String = String.Empty
    Public SWManuNameOrBrandName As String = String.Empty
    Public SWTireClass As String = String.Empty
    Public SWCategoryOfUse As String = String.Empty
    Public SoundDateOfTest As String = String.Empty
    Public SoundTestVehicle As String = String.Empty
    Public SoundTestVehicleWheelbase As String = String.Empty
    Public SoundLocationOfTestTrack As String = String.Empty
    Public SoundDateOfTrackCertification As String = String.Empty
    Public SoundTireSizeDesignation As String = String.Empty
    Public SoundTireServiceDescription As String = String.Empty
    Public SoundReferenceInflationPressure As String = String.Empty
    Public SoundTestMassFL As String = String.Empty
    Public SoundTestMassFR As String = String.Empty
    Public SoundTestMassRL As String = String.Empty
    Public SoundTestMassRR As String = String.Empty
    Public SoundTireLoadIndexFL As String = String.Empty
    Public SoundTireLoadIndexFR As String = String.Empty
    Public SoundTireLoadIndexRL As String = String.Empty
    Public SoundTireLoadIndexRR As String = String.Empty
    Public SoundInflationPressureFL As String = String.Empty
    Public SoundInflationPressureFR As String = String.Empty
    Public SoundInflationPressureRL As String = String.Empty
    Public SoundInflationPressureRR As String = String.Empty
    Public SoundTestRimWidthCode As String = String.Empty
    Public SoundTemperatureMeasurementSensorType As String = String.Empty

    Public SoundSpeed1 As String = String.Empty
    Public SoundDirectOfRun1 As String = String.Empty
    Public SoundLevelLeftMeasured1 As String = String.Empty
    Public SoundLevelRightMeasured1 As String = String.Empty
    Public SoundAirTemp1 As String = String.Empty
    Public SoundTrackTemp1 As String = String.Empty
    Public SoundLevelLeftTempCorrected1 As String = String.Empty
    Public SoundLevelRightTempCorrected1 As String = String.Empty

    Public SoundSpeed2 As String = String.Empty
    Public SoundDirectOfRun2 As String = String.Empty
    Public SoundLevelLeftMeasured2 As String = String.Empty
    Public SoundLevelRightMeasured2 As String = String.Empty
    Public SoundAirTemp2 As String = String.Empty
    Public SoundTrackTemp2 As String = String.Empty
    Public SoundLevelLeftTempCorrected2 As String = String.Empty
    Public SoundLevelRightTempCorrected2 As String = String.Empty

    Public SoundSpeed3 As String = String.Empty
    Public SoundDirectOfRun3 As String = String.Empty
    Public SoundLevelLeftMeasured3 As String = String.Empty
    Public SoundLevelRightMeasured3 As String = String.Empty
    Public SoundAirTemp3 As String = String.Empty
    Public SoundTrackTemp3 As String = String.Empty
    Public SoundLevelLeftTempCorrected3 As String = String.Empty
    Public SoundLevelRightTempCorrected3 As String = String.Empty

    Public SoundSpeed4 As String = String.Empty
    Public SoundDirectOfRun4 As String = String.Empty
    Public SoundLevelLeftMeasured4 As String = String.Empty
    Public SoundLevelRightMeasured4 As String = String.Empty
    Public SoundAirTemp4 As String = String.Empty
    Public SoundTrackTemp4 As String = String.Empty
    Public SoundLevelLeftTempCorrected4 As String = String.Empty
    Public SoundLevelRightTempCorrected4 As String = String.Empty

    Public SoundSpeed5 As String = String.Empty
    Public SoundDirectOfRun5 As String = String.Empty
    Public SoundLevelLeftMeasured5 As String = String.Empty
    Public SoundLevelRightMeasured5 As String = String.Empty
    Public SoundAirTemp5 As String = String.Empty
    Public SoundTrackTemp5 As String = String.Empty
    Public SoundLevelLeftTempCorrected5 As String = String.Empty
    Public SoundLevelRightTempCorrected5 As String = String.Empty

    Public SoundSpeed6 As String = String.Empty
    Public SoundDirectOfRun6 As String = String.Empty
    Public SoundLevelLeftMeasured6 As String = String.Empty
    Public SoundLevelRightMeasured6 As String = String.Empty
    Public SoundAirTemp6 As String = String.Empty
    Public SoundTrackTemp6 As String = String.Empty
    Public SoundLevelLeftTempCorrected6 As String = String.Empty
    Public SoundLevelRightTempCorrected6 As String = String.Empty

    Public SoundSpeed7 As String = String.Empty
    Public SoundDirectOfRun7 As String = String.Empty
    Public SoundLevelLeftMeasured7 As String = String.Empty
    Public SoundLevelRightMeasured7 As String = String.Empty
    Public SoundAirTemp7 As String = String.Empty
    Public SoundTrackTemp7 As String = String.Empty
    Public SoundLevelLeftTempCorrected7 As String = String.Empty
    Public SoundLevelRightTempCorrected7 As String = String.Empty

    Public SoundSpeed8 As String = String.Empty
    Public SoundDirectOfRun8 As String = String.Empty
    Public SoundLevelLeftMeasured8 As String = String.Empty
    Public SoundLevelRightMeasured8 As String = String.Empty
    Public SoundAirTemp8 As String = String.Empty
    Public SoundTrackTemp8 As String = String.Empty
    Public SoundLevelLeftTempCorrected8 As String = String.Empty
    Public SoundLevelRightTempCorrected8 As String = String.Empty

    Public WetDateOfTest As String = String.Empty
    Public WetTestVehicle As String = String.Empty
    Public WetLocationOfTestTrack As String = String.Empty
    Public WetTestTrackCharacteristics As String = String.Empty
    Public WetIssuedBy As String = String.Empty
    Public WetMethodOfCertification As String = String.Empty
    Public WetTestTireDetail As String = String.Empty
    Public WetTireSizeDesignation As String = String.Empty
    Public wetTireBrand As String = String.Empty
    Public WetReferenceInflationPressure As String = String.Empty

    Public WetTestTireLoadSRTT As String = String.Empty
    Public WetTestTireLoadCandidate As String = String.Empty
    Public WetTestTireLoadControl As String = String.Empty

    Public WetWaterDepthSRTT As String = String.Empty
    Public WetWaterDepthCandidate As String = String.Empty
    Public WetWaterDepthControl As String = String.Empty

    Public WetWettedTrackTemperature As String = String.Empty

    Public WetTestRimWidthCode As String = String.Empty
    Public WetTemperatureMeasurementSensorType As String = String.Empty
    Public WetIdentificationOfSRTT As String = String.Empty

    Public WetSpeed1 As String = String.Empty
    Public WetDirectOfRun1 As String = String.Empty
    Public WetSRTT1 As String = String.Empty
    Public WetCandidateTire1 As String = String.Empty
    Public WetPBFC1 As String = String.Empty
    Public WetMFDD1 As String = String.Empty
    Public WetWetGripIndex1 As String = String.Empty
    Public WetComments1 As String = String.Empty

    Public WetSpeed2 As String = String.Empty
    Public WetDirectOfRun2 As String = String.Empty
    Public WetSRTT2 As String = String.Empty
    Public WetCandidateTire2 As String = String.Empty
    Public WetPBFC2 As String = String.Empty
    Public WetMFDD2 As String = String.Empty
    Public WetWetGripIndex2 As String = String.Empty
    Public WetComments2 As String = String.Empty

    Public WetSpeed3 As String = String.Empty
    Public WetDirectOfRun3 As String = String.Empty
    Public WetSRTT3 As String = String.Empty
    Public WetCandidateTire3 As String = String.Empty
    Public WetPBFC3 As String = String.Empty
    Public WetMFDD3 As String = String.Empty
    Public WetWetGripIndex3 As String = String.Empty
    Public WetComments3 As String = String.Empty

    Public WetSpeed4 As String = String.Empty
    Public WetDirectOfRun4 As String = String.Empty
    Public WetSRTT4 As String = String.Empty
    Public WetCandidateTire4 As String = String.Empty
    Public WetPBFC4 As String = String.Empty
    Public WetMFDD4 As String = String.Empty
    Public WetWetGripIndex4 As String = String.Empty
    Public WetComments4 As String = String.Empty

    Public WetSpeed5 As String = String.Empty
    Public WetDirectOfRun5 As String = String.Empty
    Public WetSRTT5 As String = String.Empty
    Public WetCandidateTire5 As String = String.Empty
    Public WetPBFC5 As String = String.Empty
    Public WetMFDD5 As String = String.Empty
    Public WetWetGripIndex5 As String = String.Empty
    Public WetComments5 As String = String.Empty

    Public WetSpeed6 As String = String.Empty
    Public WetDirectOfRun6 As String = String.Empty
    Public WetSRTT6 As String = String.Empty
    Public WetCandidateTire6 As String = String.Empty
    Public WetPBFC6 As String = String.Empty
    Public WetMFDD6 As String = String.Empty
    Public WetWetGripIndex6 As String = String.Empty
    Public WetComments6 As String = String.Empty

    Public WetSpeed7 As String = String.Empty
    Public WetDirectOfRun7 As String = String.Empty
    Public WetSRTT7 As String = String.Empty
    Public WetCandidateTire7 As String = String.Empty
    Public WetPBFC7 As String = String.Empty
    Public WetMFDD7 As String = String.Empty
    Public WetWetGripIndex7 As String = String.Empty
    Public WetComments7 As String = String.Empty

    Public WetSpeed8 As String = String.Empty
    Public WetDirectOfRun8 As String = String.Empty
    Public WetSRTT8 As String = String.Empty
    Public WetCandidateTire8 As String = String.Empty
    Public WetPBFC8 As String = String.Empty
    Public WetMFDD8 As String = String.Empty
    Public WetWetGripIndex8 As String = String.Empty
    Public WetComments8 As String = String.Empty

    Public OriginalSound As Sound = Nothing
    Public OriginalWetGrip As WetGrip = Nothing
    Public GTSpecWetGripMatlNum As String = String.Empty
    Public GTSpecSoundMatlNum As String = String.Empty

End Class
