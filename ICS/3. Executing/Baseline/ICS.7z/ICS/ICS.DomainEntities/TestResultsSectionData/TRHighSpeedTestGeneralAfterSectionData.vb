Public Class TRHighSpeedTestGeneralAfterSectionData

    Public HighSpeedPostConditioningTime As String = String.Empty
    Public HighSpeedCircumferenceAfter As String = String.Empty
    Public HighSpeedOuterDiameterAfter As String = String.Empty
    Public HighSpeedTestInflationPressureAfter As String = String.Empty
    Public HighSpeedDifferenceOuterDiameterMMAfter As String = String.Empty
    Public HighSpeedDifferenceOuterDiameterToleranceAfter As String = String.Empty
    Public HighSpeedSeriesAfter As String = String.Empty
    Public HighSpeedFinalJudgement As Boolean = False
    Public HighSpeedApproverAfter As String = String.Empty

End Class
