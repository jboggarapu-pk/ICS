''' <summary>
''' Test Results HighSpeed Section Data - to be used in populating of UI controls
''' </summary>
''' <remarks>NOTE: Member names must match control IDs in a UI form</remarks>
Public Class TRHighSpeedSectionData

    ' Changed sku to material number as per PRJ3617 SAP Interface to International Certification System (OPQ.I.8265)Remediation.

    Public HighSpeedMatlNum As String = String.Empty

    Public HighSpeedInfPressureBefore As String = String.Empty
    Public HighSpeedTempBefore As String = String.Empty

    Public HighSpeedDurationStep0 As String = String.Empty
    Public HighSpeedDurationStep1 As String = String.Empty
    Public HighSpeedDurationStep2 As String = String.Empty
    Public HighSpeedDurationStep3 As String = String.Empty
    Public HighSpeedDurationStep4 As String = String.Empty
    Public HighSpeedDurationStep5 As String = String.Empty
    Public HighSpeedDurationStep6 As String = String.Empty
    Public HighSpeedDurationStep7 As String = String.Empty
    Public HighSpeedDurationStep8 As String = String.Empty
    Public HighSpeedDurationDate0 As String = String.Empty
    Public HighSpeedDurationDate1 As String = String.Empty
    Public HighSpeedDurationDate2 As String = String.Empty
    Public HighSpeedDurationDate3 As String = String.Empty
    Public HighSpeedDurationDate4 As String = String.Empty
    Public HighSpeedDurationDate5 As String = String.Empty
    Public HighSpeedDurationDate6 As String = String.Empty
    Public HighSpeedDurationDate7 As String = String.Empty
    Public HighSpeedDurationDate8 As String = String.Empty
    Public HighSpeedDurationTime0 As String = String.Empty
    Public HighSpeedDurationTime1 As String = String.Empty
    Public HighSpeedDurationTime2 As String = String.Empty
    Public HighSpeedDurationTime3 As String = String.Empty
    Public HighSpeedDurationTime4 As String = String.Empty
    Public HighSpeedDurationTime5 As String = String.Empty
    Public HighSpeedDurationTime6 As String = String.Empty
    Public HighSpeedDurationTime7 As String = String.Empty
    Public HighSpeedDurationTime8 As String = String.Empty
    Public HighSpeedDurationTotalTime0 As String = String.Empty
    Public HighSpeedDurationTotalTime1 As String = String.Empty
    Public HighSpeedDurationTotalTime2 As String = String.Empty
    Public HighSpeedDurationTotalTime3 As String = String.Empty
    Public HighSpeedDurationTotalTime4 As String = String.Empty
    Public HighSpeedDurationTotalTime5 As String = String.Empty
    Public HighSpeedDurationTotalTime6 As String = String.Empty
    Public HighSpeedDurationTotalTime7 As String = String.Empty
    Public HighSpeedDurationTotalTime8 As String = String.Empty
    Public HighSpeedDurationActSpeed0 As String = String.Empty
    Public HighSpeedDurationActSpeed1 As String = String.Empty
    Public HighSpeedDurationActSpeed2 As String = String.Empty
    Public HighSpeedDurationActSpeed3 As String = String.Empty
    Public HighSpeedDurationActSpeed4 As String = String.Empty
    Public HighSpeedDurationActSpeed5 As String = String.Empty
    Public HighSpeedDurationActSpeed6 As String = String.Empty
    Public HighSpeedDurationActSpeed7 As String = String.Empty
    Public HighSpeedDurationActSpeed8 As String = String.Empty
    Public HighSpeedDurationRoomTemp0 As String = String.Empty
    Public HighSpeedDurationRoomTemp1 As String = String.Empty
    Public HighSpeedDurationRoomTemp2 As String = String.Empty
    Public HighSpeedDurationRoomTemp3 As String = String.Empty
    Public HighSpeedDurationRoomTemp4 As String = String.Empty
    Public HighSpeedDurationRoomTemp5 As String = String.Empty
    Public HighSpeedDurationRoomTemp6 As String = String.Empty
    Public HighSpeedDurationRoomTemp7 As String = String.Empty
    Public HighSpeedDurationRoomTemp8 As String = String.Empty
    Public HighSpeedDurationLoad0 As String = String.Empty
    Public HighSpeedDurationLoad1 As String = String.Empty
    Public HighSpeedDurationLoad2 As String = String.Empty
    Public HighSpeedDurationLoad3 As String = String.Empty
    Public HighSpeedDurationLoad4 As String = String.Empty
    Public HighSpeedDurationLoad5 As String = String.Empty
    Public HighSpeedDurationLoad6 As String = String.Empty
    Public HighSpeedDurationLoad7 As String = String.Empty
    Public HighSpeedDurationLoad8 As String = String.Empty
    Public HighSpeedDurationLoadPerc0 As String = String.Empty
    Public HighSpeedDurationLoadPerc1 As String = String.Empty
    Public HighSpeedDurationLoadPerc2 As String = String.Empty
    Public HighSpeedDurationLoadPerc3 As String = String.Empty
    Public HighSpeedDurationLoadPerc4 As String = String.Empty
    Public HighSpeedDurationLoadPerc5 As String = String.Empty
    Public HighSpeedDurationLoadPerc6 As String = String.Empty
    Public HighSpeedDurationLoadPerc7 As String = String.Empty
    Public HighSpeedDurationLoadPerc8 As String = String.Empty

    Public HighSpeedTotalTime As String = String.Empty
    Public HighSpeedMaxSpeed As String = String.Empty
    Public HighSpeedMaxLoad As String = String.Empty
    Public HighSpeedWheelSpeedRPM As String = String.Empty
    Public HighSpeedWheelSpeedKMH As String = String.Empty
    Public HighSpeedDurationPassYN As Boolean = False

    Public HighSpeedSpeedTestTimeInitial As String = String.Empty
    Public HighSpeedSpeedTestSpeedInitial As String = String.Empty
    Public HighSpeedSpeedTestTime1 As String = String.Empty
    Public HighSpeedSpeedTestSpeed1 As String = String.Empty
    Public HighSpeedSpeedTestTime2 As String = String.Empty
    Public HighSpeedSpeedTestSpeed2 As String = String.Empty
    Public HighSpeedSpeedTestTime3 As String = String.Empty
    Public HighSpeedSpeedTestSpeed3 As String = String.Empty
    Public HighSpeedSpeedTestTime4 As String = String.Empty
    Public HighSpeedSpeedTestSpeed4 As String = String.Empty
    Public HighSpeedSpeedTestTime5 As String = String.Empty
    Public HighSpeedSpeedTestSpeed5 As String = String.Empty
    Public HighSpeedSpeedTestTime6 As String = String.Empty
    Public HighSpeedSpeedTestSpeed6 As String = String.Empty
    Public HighSpeedSpeedTestTime7 As String = String.Empty
    Public HighSpeedSpeedTestSpeed7 As String = String.Empty
    Public HighSpeedSpeedTestTime8 As String = String.Empty
    Public HighSpeedSpeedTestSpeed8 As String = String.Empty
    Public HighSpeedSpeedTestTime9 As String = String.Empty
    Public HighSpeedSpeedTestSpeed9 As String = String.Empty

    Public HighSpeedSpeedTestPassAt As String = String.Empty
    Public HighSpeedSpeedTestPassYN As Boolean = False

    Public HighSpeedInfPressureAfter As String = String.Empty
    Public HighSpeedTempAfter As String = String.Empty

    Public OriginalHighSpeed As HighSpeed = Nothing

    Public GTSpecHighSpeedMatlNum As String = String.Empty

End Class
