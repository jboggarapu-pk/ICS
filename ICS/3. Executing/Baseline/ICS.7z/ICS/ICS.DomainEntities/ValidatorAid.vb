''' <summary>
''' 
''' </summary>
''' <remarks></remarks>
Public Class ValidatorAid

    ''' <summary>
    ''' Certificate validation RuleSet names
    ''' </summary>
    ''' <remarks></remarks>
    Public Class RuleSetName

        Public Const Emark As String = "Emark"
        Public Const Imark As String = "Imark"
        Public Const CCC As String = "CCC"
        Public Const NOM As String = "NOM"
        Public Const GSO As String = "GSO"
        Public Const India_Mark As String = "India_Mark"
    End Class

    Public Const MinDateStr As String = "0001-01-01T00:00:00"
    Public Const MaxDateStr As String = "9999-12-31T23:59:59"

End Class
