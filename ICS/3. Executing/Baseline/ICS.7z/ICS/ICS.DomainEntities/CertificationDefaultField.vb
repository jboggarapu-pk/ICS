''' <summary>
''' 
''' </summary>
''' <remarks></remarks>
Public Class CertificationDefaultField

#Region "Members"

    Private m_strFieldLabel As String = String.Empty
    Private m_strFieldValue As String = String.Empty
    Private m_strFieldName As String = String.Empty
    Private m_strReportName As String = String.Empty
    Private m_strCertificateNo As String = String.Empty
    Private m_intId As Integer = 0
    Private m_intCertificateTypeId As Integer = 0
    Private m_intCertificateId As Integer = 0

#End Region

#Region "Properties"

    Public Property CertificateNo() As String
        Get
            Return m_strCertificateNo.Trim
        End Get
        Set(ByVal value As String)
            m_strCertificateNo = value
        End Set
    End Property

    Public Property Name() As String
        Get
            Return m_strFieldName.Trim
        End Get
        Set(ByVal value As String)
            m_strFieldName = value
        End Set
    End Property

    Public Property Report() As String
        Get
            Return m_strReportName.Trim
        End Get
        Set(ByVal value As String)
            m_strReportName = value
        End Set
    End Property

    Public Property CertificateTypeId() As Integer
        Get
            Return m_intCertificateTypeId
        End Get
        Set(ByVal value As Integer)
            m_intCertificateTypeId = value
        End Set
    End Property

    Public Property CertificateId() As Integer
        Get
            Return m_intCertificateId
        End Get
        Set(ByVal value As Integer)
            m_intCertificateId = value
        End Set
    End Property

    Public Property ID() As Integer
        Get
            Return m_intId
        End Get
        Set(ByVal value As Integer)
            m_intId = value
        End Set
    End Property
    Public Property Text() As String
        Get
            Return m_strFieldLabel.Trim
        End Get
        Set(ByVal value As String)
            m_strFieldLabel = value
        End Set
    End Property

    Public Property Value() As String
        Get
            Return m_strFieldValue.Trim
        End Get
        Set(ByVal value As String)
            m_strFieldValue = value
        End Set
    End Property

#End Region

End Class
