
''' <summary>
''' 
''' </summary>
''' <remarks></remarks>
Public Class HomeModel

#Region "Methods"
#End Region

End Class
