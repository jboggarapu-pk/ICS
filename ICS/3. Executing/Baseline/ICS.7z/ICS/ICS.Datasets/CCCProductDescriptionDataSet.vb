﻿

Partial Public Class CCCProductDescriptionDataSet
End Class
