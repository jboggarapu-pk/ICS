set serveroutput ON
DECLARE
  PS_SKU VARCHAR2(200);
  v_Return VARCHAR2(1);
BEGIN
  PS_SKU := '89S-205-1279';

  v_Return := ICS.TESTRESULTS_CRUD.CHECKIFPRODUCTEXISTS(PS_SKU => PS_SKU);
  
  DBMS_OUTPUT.PUT_LINE('v_Return = ' || v_Return);
  
END;