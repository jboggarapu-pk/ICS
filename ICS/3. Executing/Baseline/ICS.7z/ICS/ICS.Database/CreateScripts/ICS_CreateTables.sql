

CREATE TABLE APP_Message 
    ( 
     Seq_No NUMBER  NOT NULL , 
     Operator_ID VARCHAR2 (50 CHAR) , 
     Machine_ID VARCHAR2 (50 CHAR) , 
     Date_Recorded DATE , 
     Process_Name VARCHAR2 (100 CHAR) , 
     Recorded_Data VARCHAR2 (4000 CHAR) , 
     Message_Code VARCHAR2 (20 CHAR) , 
     Message VARCHAR2 (4000) 
    ) LOGGING 
;




ALTER TABLE APP_Message 
    ADD CONSTRAINT APP_Message_PK PRIMARY KEY ( Seq_No ) ;

CREATE TABLE ExceptionReport 
    ( 
     SKU VARCHAR2 (30) , 
     ProductDataFieldName VARCHAR2 (50) , 
     LastModified TIMESTAMP , 
     ICSValue VARCHAR2 (50) , 
     SKUMasterValue VARCHAR2 (50) 
    ) 
;


CREATE TABLE BRANDREGION 
    ( 
     RegionId NUMBER  NOT NULL , 
     BrandCode VARCHAR2 (10)  NOT NULL 
    ) LOGGING 
;



ALTER TABLE BRANDREGION 
    ADD CONSTRAINT BRANDREGION_PK PRIMARY KEY ( RegionId, BrandCode ) ;



CREATE TABLE BeadUnseatDtl 
    ( 
     BeadUnseatID NUMBER  NOT NULL , 
     UnseatForce NUMBER , 
     Iteration NUMBER , 
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CreatedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL 
    ) LOGGING
;  


CREATE TABLE BeadUnseatHdr 
    ( 
     BEADUNSEATID NUMBER  NOT NULL , 
     PROJECTNUMBER VARCHAR2 (10 CHAR) , 
     TIRENUMBER NUMBER , 
     TESTSPEC VARCHAR2 (10 CHAR) , 
     COMPLETIONDATE TIMESTAMP , 
     DOTSERIALNUMBER VARCHAR2 (20 CHAR) , 
     LOWESTUNSEATVALUE NUMBER , 
     PASSYN VARCHAR2 (1 CHAR) ,     
     SERIALDATE TIMESTAMP , 
     MINBEADUNSEAT NUMBER ,      
     TESTPASSFAIL VARCHAR2 (1 BYTE) , 
     CERTIFICATEID NUMBER (10,1)  NOT NULL,
     CERTIFICATIONTYPEID NUMBER  NOT NULL , 	 
	 CREATEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDON TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     MODIFIEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     MODIFIEDON TIMESTAMP DEFAULT SysTimeStamp  NOT NULL 
    ) LOGGING
;




COMMENT ON COLUMN BeadUnseatHdr.PassYN IS 'n->False,y->True' 
;

ALTER TABLE BeadUnseatHdr 
    ADD CONSTRAINT BeadUnseat_UN UNIQUE ( BeadUnseatID ) 
;



CREATE TABLE Brand 
    ( 
     BrandCode VARCHAR2 (10)  NOT NULL , 
     BrandName VARCHAR2 (100)  NOT NULL , 
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL 
    ) LOGGING 
;



ALTER TABLE Brand 
    ADD CONSTRAINT Brand_PK PRIMARY KEY ( BrandCode ) ;



CREATE TABLE CERTIFICATIONSEARCHTYPE 
    ( 
     CertificationTypeID NUMBER  NOT NULL , 
     TypeID NUMBER  NOT NULL 
    ) LOGGING 
;



ALTER TABLE CERTIFICATIONSEARCHTYPE 
    ADD CONSTRAINT CERTIFICATIONSEARCHTYPE_PK PRIMARY KEY ( CertificationTypeID, TypeID ) ;



CREATE TABLE Certificate 
    ( 
     CERTIFICATEID NUMBER (10,1)  NOT NULL , 
     CERTIFICATIONTYPEID NUMBER  NOT NULL , 
     CERTIFICATENUMBER VARCHAR2 (20 CHAR)  NOT NULL , 
     DATESUBMITED TIMESTAMP , 
     ACTIVESTATUS VARCHAR2 (1 BYTE) DEFAULT 'y' , 
     DATEASSIGNED_EGI TIMESTAMP , 
     DATEAPPROVED_CEGI TIMESTAMP , 
     RENEWALREQUIRED_CGIN VARCHAR2 (1 BYTE) DEFAULT 'y' , 
     SUPPLEMENTALREQUIRED_EI VARCHAR2 (1 BYTE) DEFAULT 'y' , 
     SUPPLEMENTALNUMBER_EI VARCHAR2 (30 CHAR) , 
     JOBREPORTNUMBER_CEN VARCHAR2 (30 CHAR) , 
     EXTENSION_EN VARCHAR2 (30 CHAR) , 
     SUPPLEMENTALEXTENSION_EN VARCHAR2 (30 BYTE) , 
     SUPPLEMENTALMOLDSTAMPING_E VARCHAR2 (30 CHAR) , 
     SUPPLEMENTALDATEASSIGNED_E TIMESTAMP , 
     SUPPLEMENTALDATESUBMITTED_E TIMESTAMP , 
     SUPPLEMENTALDATEAPPROVED_E TIMESTAMP , 
     EMARKREFERENCE_I VARCHAR2 (30 CHAR) , 
     EXPIRYDATE_I TIMESTAMP , 
     FAMILY_I VARCHAR2 (30 CHAR) , 
     PRODUCTLOCATION_C VARCHAR2 (50 CHAR) , 
     COUNTRYOFMANUFACTURE_N VARCHAR2 (50 CHAR) , 
     CUSTOMER_N VARCHAR2 (100 CHAR) , 
     CUSTOMERSPECIFIC_N VARCHAR2 (1 BYTE) , 
     IMPORTER_N VARCHAR2 (100 CHAR) , 
     IMPORTERADDRESS_N VARCHAR2 (200 CHAR) , 
     IMPORTERREPRESENTATIVE_N VARCHAR2 (100 CHAR) , 
     COUNTRYLOCATION_N VARCHAR2 (100 CHAR) , 
     BATCHNUMBER_G VARCHAR2 (30 CHAR) , 
     CREATEDBY VARCHAR2 (30 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDON TIMESTAMP DEFAULT SYSDATE  NOT NULL , 
     MODIFIEDBY VARCHAR2 (30 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     MODIFIEDON TIMESTAMP DEFAULT SYSDATE  NOT NULL 
    ) 
;



COMMENT ON COLUMN  CERTIFICATE.DATEAPPROVED_CEGI IS 'DateAproved_CEGI ->Used in certificationtype Emark,Imark,GSO,CC' 
;

COMMENT ON COLUMN  CERTIFICATE.SUPPLEMENTALREQUIRED_EI IS 'y forYes and n for No' 
;

ALTER TABLE  CERTIFICATE 
    ADD CONSTRAINT CERTIFICATE_PK PRIMARY KEY ( CERTIFICATIONTYPEID, CERTIFICATEID ) ;

ALTER TABLE  CERTIFICATE 
    ADD CONSTRAINT CERTIFICATE__UN UNIQUE ( CERTIFICATENUMBER ) 
;



CREATE TABLE CertificateDefaultValue 
    ( 
     FieldID NUMBER  NOT NULL , 
     CertificationTypeID NUMBER  NOT NULL ,      
     FieldValue VARCHAR2 (400 CHAR) , 
     CERTIFICATEID NUMBER  NOT NULL , 
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL
    ) LOGGING 
;





CREATE TABLE CertificateTypeDefaultValue 
    ( 
     FieldID NUMBER  NOT NULL , 
     CertificationTypeID NUMBER  NOT NULL , 
     FieldValue VARCHAR2 (400 CHAR) , 
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL
    ) LOGGING 
;





CREATE TABLE CertificationType 
    ( 
     CertificationTypeID NUMBER  NOT NULL , 
     CertificationTypeName VARCHAR2 (50) , 
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL
    ) LOGGING 
;



ALTER TABLE CertificationType 
    ADD CONSTRAINT Certification_PK PRIMARY KEY ( CertificationTypeID ) ;



CREATE TABLE Certification_Audit_LOG 
    ( 
     ChangeLogId NUMBER  NOT NULL , 
     ChangeDateTime DATE DEFAULT SYSDATE  NOT NULL , 
     ChangedBy VARCHAR2 (50 CHAR)  NOT NULL , 
     Area VARCHAR2 (50 CHAR)  NOT NULL , 
     ChangedFiled_Element VARCHAR2 (100 CHAR)  NOT NULL , 
     OLDValue VARCHAR2 (100 CHAR) , 
     NewValue VARCHAR2 (100 CHAR) , 
     ApprovalStatus VARCHAR2 (1 CHAR) DEFAULT 'p'  NOT NULL , 
     Approver VARCHAR2 (50) ,
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL
    ) LOGGING
;



COMMENT ON COLUMN Certification_Audit_LOG.ApprovalStatus IS 'A->approved,R->Rejected,P->Pending' 
;

ALTER TABLE Certification_Audit_LOG 
    ADD CONSTRAINT Certification_Audit_LOG_PK PRIMARY KEY ( ChangeLogId ) ;



CREATE TABLE Country 
    ( 
     CountryId NUMBER  NOT NULL , 
     CountryName VARCHAR2 (70) , 
    CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     RegionId NUMBER , 
     CertificationTypeID NUMBER 
    ) LOGGING 
;



ALTER TABLE Country 
    ADD CONSTRAINT Country_PK PRIMARY KEY ( CountryId ) ;



CREATE TABLE DefaultField 
    ( 
     FieldID NUMBER  NOT NULL , 
     FieldName VARCHAR2 (50 CHAR) , 
     FieldText VARCHAR2 (200 CHAR) , 
     CertificationTypeID NUMBER  NOT NULL , 
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL
    ) LOGGING 
;



ALTER TABLE DefaultField 
    ADD CONSTRAINT DefaultFielt_PK PRIMARY KEY ( FieldID, CertificationTypeID ) ;



CREATE TABLE EnduranceDtl 
    ( 
     TestStep NUMBER , 
     TimeInMin NUMBER , 
     Speed NUMBER (10,3) , 
     TotMiles NUMBER (10,3) , 
     Load NUMBER (10,3) , 
     LoadPercent NUMBER (10,3) , 
     SetInflation NUMBER , 
     AmbTemp NUMBER , 
     InfPressure NUMBER , 
     StepCompletionDate Varchar2(30) , 
     EnduranceID NUMBER  NOT NULL , 
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CreatedOn TIMESTAMP DEFAULT SYSTImeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SYSTImeStamp  NOT NULL 
    ) LOGGING 
;






CREATE TABLE EnduranceHdr 
    ( 
     ENDURANCEID NUMBER  NOT NULL , 
     PROJECTNUMBER VARCHAR2 (10 BYTE) , 
     TIRENUMBER NUMBER , 
     TESTSPEC VARCHAR2 (10 CHAR) , 
     COMPLETIONDATE TIMESTAMP , 
     DOTSERIALNUMBER VARCHAR2 (20 CHAR) , 
     MFGWWYY VARCHAR2 (20 CHAR) , 
     PRECONDSTARTDATE TIMESTAMP , 
     PRECONDSTARTTEMP NUMBER , 
     RIMDIAMETER NUMBER (10,5) , 
     RIMWIDTH NUMBER (10,5) , 
     PRECONDENDDATE TIMESTAMP , 
     PRECONDENDTEMP NUMBER , 
     INFLATIONPRESSURE NUMBER (10,5) , 
     BEFOREDIAMETER NUMBER (10,5) , 
     AFTERDIAMETER NUMBER (10,5) , 
     BEFOREINFLATION NUMBER , 
     AFTERINFLATION NUMBER , 
     WHEELPOSITION NUMBER , 
     WHEELNUMBER NUMBER , 
     FINALTEMP NUMBER , 
     FINALDISTANCE NUMBER (10,5) , 
     FINALINFLATION NUMBER , 
     POSTCONDSTARTDATE TIMESTAMP , 
     POSTCONDENDDATE TIMESTAMP , 
     POSTCONDENDTEMP NUMBER , 
     PASSYN VARCHAR2 (1 BYTE) , 
     SERIALDATE TIMESTAMP , 
     PRECONDTIME NUMBER (10,5) , 
     POSTCONDTIME NUMBER (10,5) , 
     DIAMETERTESTDRUM NUMBER (10,5) , 
     PRECONDTEMP NUMBER (10,5) , 
     INFLATIONPRESSUREREADJUSTED NUMBER (10,5) , 
     CIRCUNFERENCEBEFORETEST NUMBER (10,5) , 
     RESULTPASSFAIL VARCHAR2 (1 BYTE) , 
     ENDURANCEHOURS NUMBER (10,5) , 
     POSSIBLEFAILURESFOUND VARCHAR2 (10 BYTE) , 
     CIRCUNFERENCEAFTERTEST NUMBER (10,5) , 
     OUTERDIAMETERDIFERENCE NUMBER (10,5) , 
     ODDIFERENCETOLERANCE NUMBER (10,5) , 
     SERIENOM VARCHAR2 (50 BYTE) , 
     FINALJUDGEMENT VARCHAR2 (1 BYTE) , 
     APPROVER VARCHAR2 (100 BYTE) , 
     CERTIFICATEID NUMBER (10,1)  NOT NULL , 
     CERTIFICATIONTYPEID NUMBER  NOT NULL , 
     CREATEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDON TIMESTAMP DEFAULT SYSTImeStamp  NOT NULL , 
     MODIFIEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     MODIFIEDON TIMESTAMP DEFAULT SYSTImeStamp  NOT NULL 
    ) LOGGING
;  




COMMENT ON COLUMN EnduranceHdr.PassYN IS 'n->False,y->True' 
;

COMMENT ON COLUMN EnduranceHdr.ResultPassFail IS 'n->False,y->True' 
;

COMMENT ON COLUMN EnduranceHdr.EnduranceHours IS 'n->False,y->True' 
;

COMMENT ON COLUMN EnduranceHdr.PossibleFailuresFound IS 'n->False,y->True' 
;

ALTER TABLE EnduranceHdr 
    ADD CONSTRAINT Endurance_UN UNIQUE ( EnduranceID ) 
;



CREATE TABLE HighSpeedDtl 
    ( 
     TestStep NUMBER , 
     TimeInMin NUMBER , 
     Speed NUMBER (10,3) , 
     TotMiles NUMBER (10,3) , 
     Load NUMBER (10,3) , 
     LoadPercent NUMBER (10,3) , 
     SetInflation NUMBER , 
     AmbTemp NUMBER , 
     InfPressure NUMBER , 
     StepCompletionDate Varchar2(30) , 
     HighSpeedID NUMBER  NOT NULL , 
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CreatedON TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SYSTImeStamp  NOT NULL 
    ) LOGGING 
;





CREATE TABLE HighSpeedHdr 
    ( 
     HIGHSPEEDID NUMBER  NOT NULL , 
     PROJECTNUMBER VARCHAR2 (10 CHAR) , 
     TIRENUM NUMBER , 
     TESTSPEC VARCHAR2 (10 CHAR) , 
     COMPETIONDATE TIMESTAMP , 
     DOTSERIALNUMBER VARCHAR2 (20 CHAR) , 
     MFGWWYY VARCHAR2 (20 CHAR) , 
     PRECONDSTARTDATE TIMESTAMP , 
     PRECONDSARTTEMP NUMBER , 
     RIMDIAMETER NUMBER (10,3) , 
     RIMWIDTH NUMBER (10,3) , 
     PRECONDENDDATE TIMESTAMP , 
     PRECONDENDTEMP NUMBER , 
     INFLATIONPRESSURE NUMBER , 
     BEFOREDIAMETER NUMBER (10,5) , 
     AFTERDIAMETER NUMBER (10,5) , 
     BEFOREINFLATION NUMBER (10,5) , 
     AFTERINFLATION NUMBER (10,5) , 
     WHEELPOSITION NUMBER (10,5) , 
     WHEELNUMBER NUMBER (10,5) , 
     FINALTEMP NUMBER (10,5) , 
     FINALDISTANCE NUMBER (10,5) , 
     FINALINFLATION NUMBER (10,5) , 
     POSTCONDSTARTDATE TIMESTAMP , 
     POSTCONDENDDATE TIMESTAMP , 
     POSTCONDENDTEMP NUMBER , 
     PASSYN VARCHAR2 (1 CHAR) , 
     SERIALDATE TIMESTAMP , 
     POSTCONDTIME NUMBER (10,5) , 
     DIAMETERTESTDRUM NUMBER (10,5) , 
     PRECONDTIME NUMBER (10,5) , 
     PRECONDTEMP NUMBER (10,5) , 
     INFLATIONPRESSUREREADJUSTED NUMBER (10,5) , 
     CIRCUNFERENCEBEFORETEST NUMBER (10,5) , 
     WHEELSPEEDRPM NUMBER (10,5) , 
     WHEELSPEEDKMH NUMBER (10,5) , 
     CIRCUNFERENCEAFTERTEST NUMBER (10,5) , 
     ODDIFERENCE NUMBER (10,5) , 
     ODDIFERENCETOLERANCE NUMBER (10,5) , 
     SERIENOM VARCHAR2 (50 BYTE) , 
     FINALJUDGEMENT VARCHAR2 (1 BYTE) , 
     APPROVER VARCHAR2 (100 BYTE) , 
     PASSATKMH NUMBER (10,5) , 
     SPEEDTTESTPASSFAIL VARCHAR2 (1 BYTE) , 
     SPEEDTOTALTIME NUMBER (10,5) , 
     MAXSPEED NUMBER (10,5) , 
     MAXLOAD NUMBER (10,5) , 
     CERTIFICATEID NUMBER (10,1)  NOT NULL , 
     CERTIFICATIONTYPEID NUMBER  NOT NULL , 
     CREATEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDON TIMESTAMP DEFAULT SYSTImeStamp  NOT NULL , 
     MODIFIEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     MODIFIEDON TIMESTAMP DEFAULT SYSTImeStamp  NOT NULL 
    ) LOGGING 
; 




COMMENT ON COLUMN HighSpeedHdr.PassYN IS '''n->False,y->True''' 
;

COMMENT ON COLUMN HighSpeedHdr.FinalJudgement IS '''n->False,y->True''' 
;

COMMENT ON COLUMN HighSpeedHdr.Approver IS '''n->False,y->True''' 
;

ALTER TABLE HighSpeedHdr 
    ADD CONSTRAINT HighSpeed_HighSpeedID_UN UNIQUE ( HighSpeedID ) 
;



CREATE TABLE MEASUREDTL 
    ( 
     MEASUREID NUMBER  NOT NULL , 
     SECTIONWIDTH NUMBER (10,3) , 
     OVERALLWIDTH NUMBER (10,3) , 
     ITERATION NUMBER , 
     CREATEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDON TIMESTAMP DEFAULT SYSTImeStamp  NOT NULL , 
     MODIFIEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     MODIFIEDON TIMESTAMP DEFAULT SYSTImeStamp  NOT NULL 
    ) LOGGING
;





CREATE TABLE MeasureHdr 
    ( 
     MEASUREID NUMBER  NOT NULL , 
     PROJECTNUMBER VARCHAR2 (10 CHAR)  , 
     TIRENUMBER NUMBER  , 
     TESTSPEC VARCHAR2 (10 CHAR) , 
     COMPLETIONDATE TIMESTAMP , 
     INFLATIONPRESSURE NUMBER (10,3) , 
     MOLDDESIGN VARCHAR2 (20 CHAR) , 
     RIMWIDTH NUMBER (10,3) , 
     DOTSERIALNUMBER VARCHAR2 (20 CHAR) , 
     DIAMETER NUMBER (10,3) , 
     AVGSECTIONWIDTH NUMBER (10,3) , 
     AVGOVERALLWIDTH NUMBER (10,3) , 
     MAXOVERALLWIDTH NUMBER (10,3) , 
     SIZEFACTOR NUMBER (10,3) , 
     MOUNTTIME DATE , 
     MOUNTTEMP NUMBER (10,3) , 
     SERIALDATE TIMESTAMP , 
     ENDTIME TIMESTAMP , 
     ACTSIZEFACTOR NUMBER (10,3) , 
     STARTINFLATIONPRESSURE NUMBER (10,3) , 
     ENDINFLATIONPRESSURE NUMBER (10,3) , 
     ADJUSTMENT VARCHAR2 (50 BYTE) , 
     CIRCUNFERENCE NUMBER (10,5) , 
     NOMINALDIAMETER NUMBER (10,5) , 
     NOMINALWIDTH NUMBER (10,5) , 
     NOMINALWIDTHPASSFAIL VARCHAR2 (1 BYTE) DEFAULT 'y' , 
     NOMINALWIDTHDIFERENCE NUMBER (10,5) , 
     NOMINALWIDTHTOLERANCE NUMBER (10,5) , 
     MAXOVERALLDIAMETER NUMBER (10,5) , 
     MINOVERALLDIAMETER NUMBER (10,5) , 
     OVERALLWIDTHPASSFAIL VARCHAR2 (1 BYTE) DEFAULT 'y' , 
     OVERALLDIAMETERPASSFAIL VARCHAR2 (1 BYTE) DEFAULT 'y' , 
     DIAMETERDIFERENCE NUMBER (10,5) , 
     DIAMETERTOLERANCE NUMBER (10,5) , 
     TEMPRESISTANCEGRADING NUMBER (10,5) , 
     TENSILESTRENGHT1 NUMBER (10,5) , 
     TENSILESTRENGHT2 NUMBER (10,5) , 
     ELONGATION1 NUMBER (10,5) , 
     ELONGATION2 NUMBER (10,5) , 
     TENSILESTRENGHTAFTERAGE1 NUMBER (10,5) , 
     TENSILESTRENGHTAFTERAGE2 NUMBER (10,5) , 
     CERTIFICATEID NUMBER (10,1)  NOT NULL , 
     CERTIFICATIONTYPEID NUMBER  NOT NULL , 
     CREATEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDON TIMESTAMP DEFAULT SYSTImeStamp  NOT NULL , 
     MODIFIEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     MODIFIEDON TIMESTAMP DEFAULT SYSTImeStamp  NOT NULL 
    ) 
;



ALTER TABLE MeasureHdr 
    ADD CONSTRAINT Measure_UN UNIQUE ( MeasureID ) 
;



CREATE TABLE NPR_Master 
    ( 
     NprId NUMBER  NOT NULL , 
     CustomerName VARCHAR2 (100) , 
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL
    ) LOGGING 
;



ALTER TABLE NPR_Master 
    ADD CONSTRAINT NPR_Master_PK PRIMARY KEY ( NprId ) ;



CREATE TABLE PlungerDtl 
    ( 
     PlungerID NUMBER  NOT NULL , 
     BreakingEnergy NUMBER , 
     Iteration NUMBER , 
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CreatedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL 
    ) LOGGING 
;

CREATE TABLE PlungerHdr 
    ( 
     PLUNGERID NUMBER  NOT NULL , 
     PROJECTNUMBER VARCHAR2 (10 BYTE) , 
     TIRENUMBER NUMBER , 
     TESTSPEC VARCHAR2 (10 CHAR) , 
     COMPLETIONDATE TIMESTAMP , 
     DOTSERIALNUMBER VARCHAR2 (20 CHAR) , 
     AVGBREAKINGENERGY NUMBER , 
     PASSYN VARCHAR2 (1 CHAR) , 
     SERIALDATE TIMESTAMP , 
     MINPLUNGER NUMBER (18) ,     
     CERTIFICATIONTYPEID NUMBER  NOT NULL , 
     CERTIFICATEID NUMBER (10,1)  NOT NULL ,
	 CREATEDON VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDBY TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     MODIFIEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     MODIFIEDON TIMESTAMP DEFAULT SysTimeStamp  NOT NULL 
    ) LOGGING 
;



COMMENT ON COLUMN PlungerHdr.PassYN IS '0->False,1->True' 
;

ALTER TABLE PlungerHdr 
    ADD CONSTRAINT Plunger_UN UNIQUE ( PlungerID ) 
;



CREATE TABLE Product 
    ( 
     SKUID NUMBER  NOT NULL , 
     SKU VARCHAR2 (30)  NOT NULL , 
     BrandCode VARCHAR2 (10) , 
     TireTypeId NUMBER , 
     NprId NUMBER , 
     SizeStamp VARCHAR2 (20)  NOT NULL , 
     DiscontinuedDate TIMESTAMP , 
     SpecNumber VARCHAR2 (30) , 
     SpeedRating VARCHAR2 (10 CHAR) , 
     SingLoadIndex VARCHAR2 (10 CHAR) , 
     DualLoadIndex VARCHAR2 (10 CHAR) , 
     BeltedRadialYN VARCHAR2 (1 CHAR) , 
     TubelessYN VARCHAR2 (1 CHAR) , 
     ReinforcedYN VARCHAR2 (1 CHAR) , 
     ExtraLoadYN VARCHAR2 (1 CHAR) , 
     UTQGTreadwear VARCHAR2 (10 CHAR) , 
     UTQGTraction VARCHAR2 (10 CHAR) , 
     UTQGTemp VARCHAR2 (10 CHAR) , 
     MudSnowYN VARCHAR2 (1 CHAR) , 
     RimDiameter NUMBER , 
     SerialDate TIMESTAMP , 
     BrandDesc VARCHAR2 (100 CHAR) , 
     LoadRange VARCHAR2 (30 CHAR) , 
     MeaRimWidth NUMBER (10,3) , 
     RegroovableInd VARCHAR2 (30 CHAR) , 
     PlantProduced VARCHAR2 (50 CHAR) , 
     MostRecentTestDate TIMESTAMP , 
     IMark VARCHAR2 (30 CHAR) , 
     CreatedBy VARCHAR2 (50)  DEFAULT 'ICSDEV'      NOT NULL , 
     CreatedOn TIMESTAMP      DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50) DEFAULT 'ICSDEV'      NOT NULL , 
     ModifiedOn TIMESTAMP     DEFAULT SysTimeStamp  NOT NULL , 
     InformeNumber VARCHAR2 (50) , 
     Fechadate TIMESTAMP , 
     TreadPattern VARCHAR2 (50) , 
     SpecialProtectiveBand VARCHAR2 (50) , 
     NominalTireWidth VARCHAR2 (50) , 
     AspectRadio VARCHAR2 (50) , 
     TreadWearIndicators VARCHAR2 (50) , 
     NameOfManufacturer VARCHAR2 (100) , 
     Family VARCHAR2 (50) , 
     DOTSerialNumber VARCHAR2 (15) 
    ) 
;



COMMENT ON COLUMN Product.BeltedRadialYN IS 'n->False,y->True' 
;

COMMENT ON COLUMN Product.TubelessYN IS 'n->False,y->True' 
;

COMMENT ON COLUMN Product.ReinforcedYN IS 'n->False,y->True' 
;

COMMENT ON COLUMN Product.ExtraLoadYN IS 'n->False,y->True' 
;

COMMENT ON COLUMN Product.MudSnowYN IS 'n->False,y->True' 
;

ALTER TABLE Product 
    ADD CONSTRAINT Product_PK PRIMARY KEY ( SKUID ) ;

CREATE TABLE CUSTOMER 
    ( 
     CUSTOMER VARCHAR2 (100)  NOT NULL , 
     IMPORTER VARCHAR2 (100) , 
     IMPORTERREPRESENTATIVE VARCHAR2 (100) , 
     IMPORTERADDRESS VARCHAR2 (200) , 
     COUNTRYLOCATION VARCHAR2 (100) , 
     SKUID NUMBER  NOT NULL 
    ) 
;



ALTER TABLE CUSTOMER 
    ADD CONSTRAINT Customer_PK PRIMARY KEY ( CUSTOMER, SKUID ) ;



ALTER TABLE CUSTOMER 
    ADD CONSTRAINT Customer_PRODUCT_FK FOREIGN KEY 
    ( 
     SKUID
    ) 
    REFERENCES PRODUCT 
    ( 
     SKUID
    ) 
;



CREATE TABLE ProductCertificate 
    ( 
     SKUID NUMBER  NOT NULL , 
     CERTIFICATIONTYPEID NUMBER  NOT NULL , 
     CERTIFICATEID NUMBER (10,1)  NOT NULL , 
     CREATEDBY VARCHAR2 (50 BYTE) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDON TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     MODIFIEDBY VARCHAR2 (50 BYTE) DEFAULT 'ICSDEV'  NOT NULL , 
     MODIFIEDON TIMESTAMP DEFAULT SysTimeStamp  NOT NULL 
    ) LOGGING 
;





CREATE TABLE ProductCountry 
    ( 
     CountryId           NUMBER  NOT NULL , 
     CertificationTypeId NUMBER , 
     RequestStatus       VARCHAR2 (1) , 
     SKUId               NUMBER NOT NULL , 
     CreatedBy           VARCHAR2 (50) DEFAULT 'ICSDEV' , 
     CreatedOn           TIMESTAMP DEFAULT SysTimeStamp , 
     ModifiedBy          VARCHAR2 (50) DEFAULT 'ICSDEV' , 
     ModifiedOn          TIMESTAMP DEFAULT SysTimeStamp 
    ) LOGGING
;



COMMENT ON COLUMN ProductCountry.RequestStatus IS 'RequestStatus
Char(1) -R-> Requested,I->InProgress,A->Approved' 
;

ALTER TABLE ProductCountry 
    ADD CONSTRAINT ProductCountry_PK PRIMARY KEY ( CountryId, SKUId ) ;



--  Table that contain the manes and data related to the regions of the world
--  (continents)
CREATE TABLE Region 
    ( 
     RegionId NUMBER  NOT NULL , 
     RegionName VARCHAR2 (30 CHAR) , 
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL 
    ) LOGGING 
;



ALTER TABLE Region 
    ADD CONSTRAINT Region_PK PRIMARY KEY ( RegionId ) ;



CREATE TABLE SKUMain 
    ( 
     SKU VARCHAR2 (30 CHAR)  NOT NULL , 
     SizeStamp VARCHAR2 (20) , 
     BrandCode VARCHAR2 (10 CHAR)  NOT NULL ,
     TireTypeId NUMBER , 
     NprId NUMBER ,    
     DiscontinuedDate TIMESTAMP , 
     SpecNumber VARCHAR2 (30) , 
     SpeedRating VARCHAR2 (10 CHAR) , 
     SingLoadIndex VARCHAR2 (10 CHAR) , 
     DualLoadIndex VARCHAR2 (10 CHAR) , 
     BeltedRadialYN VARCHAR2 (1 CHAR) , 
     TubelessYN VARCHAR2 (1 CHAR) , 
     ReinforcedYN VARCHAR2 (1 CHAR) , 
     ExtraLoadYN VARCHAR2 (1 CHAR) , 
     MeasuringRim VARCHAR2 (10 CHAR) , 
     UTQGTreadwear VARCHAR2 (10 CHAR) , 
     UTQGTraction VARCHAR2 (10 CHAR) , 
     UTQGTemp VARCHAR2 (10 CHAR) , 
     MudSnowYN VARCHAR2 (1 CHAR) , 
     RimDiameter NUMBER , 
     SerialDate TIMESTAMP , 
     BrandDesc VARCHAR2 (100 CHAR) , 
     LoadRange VARCHAR2 (30 CHAR) , 
     MeaRimWidth NUMBER (10,3) , 
     RegroovableInd VARCHAR2 (30 CHAR) , 
     PlantProduced VARCHAR2 (50 CHAR) , 
     MostRecentTestDate TIMESTAMP , 
     IMark VARCHAR2 (30 CHAR) ,      
     InformeNumber VARCHAR2 (50) , 
     Fechadate TIMESTAMP , 
     TreadPattern VARCHAR2 (50) , 
     SpecialProtectiveBand VARCHAR2 (50) , 
     NominalTireWidth VARCHAR2 (50) , 
     AspectRadio VARCHAR2 (50) , 
     TreadWearIndicators VARCHAR2 (50) , 
     NameOfManufacturer VARCHAR2 (100) , 
     Family VARCHAR2 (50) , 
     DOTSerialNumber VARCHAR2 (15) ,
     CreatedBy VARCHAR2 (50)  DEFAULT 'ICSDEV'      NOT NULL , 
     CreatedOn TIMESTAMP      DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50) DEFAULT 'ICSDEV'      NOT NULL , 
     ModifiedOn TIMESTAMP     DEFAULT SysTimeStamp  NOT NULL 
    ) LOGGING 
;

CREATE TABLE SearchType 
    ( 
     TypeID NUMBER  NOT NULL , 
     TypeName VARCHAR2 (20) , 
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL
    ) LOGGING 
;



ALTER TABLE SearchType 
    ADD CONSTRAINT SearchType_PK PRIMARY KEY ( TypeID ) ;



CREATE TABLE SoundDetail 
    ( 
     Iteration NUMBER , 
     TestSpeed VARCHAR2 (50 CHAR) , 
     DirectionOfRun VARCHAR2 (50 CHAR) , 
     SoundLevelLeft VARCHAR2 (50 CHAR) , 
     SoundLevelRight VARCHAR2 (50 CHAR) , 
     AirTemp VARCHAR2 (50 CHAR) , 
     TrackTemp VARCHAR2 (50 CHAR) , 
     SoundLevelLeft_TempCorrected VARCHAR2 (50 CHAR) , 
     SoundLevelRight_TempCorrected VARCHAR2 (50 CHAR) , 
     SoundID NUMBER  NOT NULL , 
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL
    ) LOGGING 
;





CREATE TABLE SoundHdr 
    ( 
     SOUNDID NUMBER , 
     PROJECTNUMBER VARCHAR2 (10 CHAR) , 
     TIRENUMBER NUMBER , 
     TESTSPEC VARCHAR2 (10 CHAR) , 
     TESTREPORTNUMBER VARCHAR2 (50 CHAR) , 
     MANUFACTUREANDBRAND VARCHAR2 (60 CHAR) , 
     TIRECLASS VARCHAR2 (50 CHAR) , 
     CATEGORYOFUSE VARCHAR2 (50 CHAR) , 
     DATEOFTEST TIMESTAMP , 
     TESTVEHICULE VARCHAR2 (50 CHAR) , 
     TESTVEHICULEWHEELBASE VARCHAR2 (50 CHAR) , 
     LOCATIONOFTESTTRACK VARCHAR2 (50 BYTE) , 
     DATETRACKCERTIFTOISO TIMESTAMP , 
     TIRESIZEDESIGNATION VARCHAR2 (50 BYTE) , 
     TIRESERVICEDESCRIPTION VARCHAR2 (50 CHAR) , 
     TESTMASS_FRONTL VARCHAR2 (20 CHAR) , 
     TESTMASS_FRONTR VARCHAR2 (20 CHAR) , 
     TESTMASS_REARL VARCHAR2 (20 CHAR) , 
     TESTMASS_REARR VARCHAR2 (20 CHAR) , 
     TIRELOADINDEX_FRONTL VARCHAR2 (20 CHAR) , 
     TIRELOADINDEX_FRONTR VARCHAR2 (20 CHAR) , 
     TIRELOADINDEX_REARL VARCHAR2 (20 CHAR) , 
     TIRELOADINDEX_REARR VARCHAR2 (20 CHAR) , 
     INFLATIONPRESSURECO_FRONTL VARCHAR2 (20 CHAR) , 
     INFLATIONPRESSURECO_FRONTR VARCHAR2 (20 CHAR) , 
     INFLATIONPRESSURECO_REARL VARCHAR2 (20 CHAR) , 
     INFLATIONPRESSURECO_REARR VARCHAR2 (20 CHAR) , 
     TESTRIMWIDTHCODE VARCHAR2 (20 CHAR) , 
     TEMPMEASURESENSORTYPE VARCHAR2 (20 CHAR) , 
     REFERENCEINFLATIONPRESSURE VARCHAR2 (20 CHAR) , 
     CREATEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDON TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     MODIFIEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     MODIFIEDON TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     CERTIFICATIONTYPEID NUMBER  NOT NULL , 
     CERTIFICATEID NUMBER (10,1)  NOT NULL 
    ) LOGGING 
;



ALTER TABLE SoundHdr 
    ADD CONSTRAINT SoundHdrID_UN UNIQUE ( SoundID ) 
;



CREATE TABLE SpeedTestDetail 
    ( 
     Iteration NUMBER , 
     Time DATE , 
     Speed NUMBER (10,5) , 
     HighSpeedID NUMBER  NOT NULL ,
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL
    ) LOGGING 
;





CREATE TABLE TireType 
    ( 
     TireTypeId NUMBER  NOT NULL , 
     TireTypeName VARCHAR2 (30) ,
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP DEFAULT SysTimeStamp  NOT NULL
    ) LOGGING 
;



ALTER TABLE TireType 
    ADD CONSTRAINT TireType_PK PRIMARY KEY ( TireTypeId ) ;



CREATE TABLE TreadWearDtl 
    ( 
     TreadWearID NUMBER  NOT NULL , 
     WearbarHeight NUMBER (10,3) , 
     Iteration NUMBER , 
     CreatedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV' NOT NULL, 
     CreatedOn TIMESTAMP DEFAULT SYSTImeStamp NOT NULL, 
     ModifiedBy VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV' NOT NULL, 
     ModifiedOn TIMESTAMP DEFAULT SYSTImeStamp NOT NULL
    ) LOGGING 
;






CREATE TABLE TreadWearHdr 
    ( 
     TREADWEARID NUMBER  NOT NULL , 
     PROJECTNUMBER VARCHAR2 (10 CHAR)  , 
     TIRENUMBER NUMBER   , 
     TESTSPEC VARCHAR2 (10 CHAR)  , 
     COMPLETIONDATE TIMESTAMP , 
     DOTSERIALNUMBER VARCHAR2 (20 CHAR) , 
     LOWESTWEARBAR NUMBER (10,3) , 
     PASSYN VARCHAR2 (1 CHAR) , 
     SERIALDATE TIMESTAMP , 
     INDICATORSREQUIREMENT NUMBER (10,5) , 
     CREATEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDON TIMESTAMP DEFAULT SYSTImeStamp  NOT NULL , 
     MODIFIEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     MODIFIEDON TIMESTAMP DEFAULT SYSTImeStamp  NOT NULL , 
     CERTIFICATIONTYPEID NUMBER  NOT NULL , 
     CERTIFICATEID NUMBER (10,1)  NOT NULL 
    ) LOGGING 
;



COMMENT ON COLUMN TreadWearHdr.PassYN IS 'n->False,y->True' 
;

ALTER TABLE TreadWearHdr 
    ADD CONSTRAINT TreadWear_UN UNIQUE ( TreadWearID ) 
;



CREATE TABLE WetGripDetail 
    ( 
     Iteration NUMBER , 
     TestSpeed VARCHAR2 (50 CHAR) , 
     DirectionOfRun VARCHAR2 (50 CHAR) , 
     SRTT VARCHAR2 (50) , 
     CandidateTire VARCHAR2 (50 CHAR) , 
     PeakBreakForceCoeficient VARCHAR2 (50 CHAR) , 
     MeanFullyDevelopedDeceleration VARCHAR2 (50 CHAR) , 
     WetGripIndex VARCHAR2 (50 CHAR) , 
     Comments VARCHAR2 (100 CHAR) , 
     WetGripID NUMBER  NOT NULL , 
     CreatedBy VARCHAR2 (50) DEFAULT 'ICSDEV'  NOT NULL , 
     CreatedOn TIMESTAMP  DEFAULT SYSTImeStamp  NOT NULL , 
     ModifiedBy VARCHAR2 (50) DEFAULT 'ICSDEV'  NOT NULL , 
     ModifiedOn TIMESTAMP  DEFAULT SYSTImeStamp  NOT NULL 
    ) LOGGING 
;





CREATE TABLE WetGripHdr 
    ( 
     WETGRIPID NUMBER , 
     PROJECTNUMBER VARCHAR2 (10 CHAR) , 
     TIRENUMBER NUMBER , 
     TESTSPEC VARCHAR2 (10 CHAR) , 
     DATEOFTEST TIMESTAMP , 
     TESTVEHICLE VARCHAR2 (50 CHAR) , 
     LOCATIONOFTESTTRACK VARCHAR2 (60 CHAR) , 
     TESTTRACKCHARACTERISTICS VARCHAR2 (80 CHAR) , 
     ISSUEBY VARCHAR2 (50 CHAR) , 
     METHODOFCERTIFICATION VARCHAR2 (50 CHAR) , 
     TESTTIREDETAILS VARCHAR2 (100 CHAR) , 
     TIRESIZEANDSERVICEDESC VARCHAR2 (100 CHAR) , 
     TIREBRANDANDTRADEDESC VARCHAR2 (100 CHAR) , 
     REFERENCEINFLATIONPRESSURE VARCHAR2 (10 BYTE) , 
     TESTRIMWITHCODE VARCHAR2 (50 CHAR) , 
     TEMPMEASURESENSORTYPE VARCHAR2 (50 CHAR) , 
     IDENTIFICATIONSRTT VARCHAR2 (50 CHAR) , 
     TESTTIRELOAD_SRTT VARCHAR2 (50 CHAR) , 
     TESTTIRELOAD_CANDIDATE VARCHAR2 (50 CHAR) , 
     TESTTIRELOAD_CONTROL VARCHAR2 (50 CHAR) , 
     WATERDEPTH_SRTT VARCHAR2 (50 CHAR) , 
     WATERDEPTH_CANDIDATE VARCHAR2 (50 CHAR) , 
     WATERDEPTH_CONTROL VARCHAR2 (50 CHAR) , 
     WETTEDTRACKTEMPAVG VARCHAR2 (50 CHAR) , 
     CREATEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     CREATEDON TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     MODIFIEDBY VARCHAR2 (50 CHAR) DEFAULT 'ICSDEV'  NOT NULL , 
     MODIFIEDON TIMESTAMP DEFAULT SysTimeStamp  NOT NULL , 
     CERTIFICATIONTYPEID NUMBER  NOT NULL , 
     CERTIFICATEID NUMBER (10,1)  NOT NULL 
    ) LOGGING 
;



ALTER TABLE WetGripHdr 
    ADD CONSTRAINT WetGripHdr_UN UNIQUE ( WetGripID ) 
;




ALTER TABLE BeadUnseatDtl 
    ADD CONSTRAINT BeadUnseatDetail_BeadUnseat_FK FOREIGN KEY 
    ( 
     BeadUnseatID
    ) 
    REFERENCES BeadUnseatHdr 
    ( 
     BeadUnseatID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE  BEADUNSEATHDR 
    ADD CONSTRAINT BEADUNSEATHDR_CERTIFICATE_FK FOREIGN KEY 
    ( 
     CERTIFICATIONTYPEID,
     CERTIFICATEID
    ) 
    REFERENCES  CERTIFICATE 
    ( 
     CERTIFICATIONTYPEID,
     CERTIFICATEID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE BRANDREGION 
    ADD CONSTRAINT Brand_FK01 FOREIGN KEY 
    ( 
     BrandCode
    ) 
    REFERENCES Brand 
    ( 
     BrandCode
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;



ALTER TABLE Product 
    ADD CONSTRAINT Brand_FK02 FOREIGN KEY 
    ( 
     BrandCode
    ) 
    REFERENCES Brand 
    ( 
     BrandCode
    ) 
    ON DELETE SET NULL 
    NOT DEFERRABLE 
;



ALTER TABLE CertificateDefaultValue 
    ADD CONSTRAINT CertificationDefaultField_FK04 FOREIGN KEY 
    ( 
     FieldID,
     CertificationTypeID
    ) 
    REFERENCES DefaultField 
    ( 
     FieldID,
     CertificationTypeID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE CertificateTypeDefaultValue 
    ADD CONSTRAINT CertificationTypeDefault_FK01 FOREIGN KEY 
    ( 
     FieldID,
     CertificationTypeID
    ) 
    REFERENCES DefaultField 
    ( 
     FieldID,
     CertificationTypeID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE Certificate 
    ADD CONSTRAINT CertificationType_FK01 FOREIGN KEY 
    ( 
     CertificationTypeID
    ) 
    REFERENCES CertificationType 
    ( 
     CertificationTypeID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE DefaultField 
    ADD CONSTRAINT CertificationType_FK03 FOREIGN KEY 
    ( 
     CertificationTypeID
    ) 
    REFERENCES CertificationType 
    ( 
     CertificationTypeID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE CERTIFICATIONSEARCHTYPE 
    ADD CONSTRAINT CertificationType_ID_FK FOREIGN KEY 
    ( 
     CertificationTypeID
    ) 
    REFERENCES CertificationType 
    ( 
     CertificationTypeID
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;



ALTER TABLE Country 
    ADD CONSTRAINT Certification_FK01 FOREIGN KEY 
    ( 
     CertificationTypeID
    ) 
    REFERENCES CertificationType 
    ( 
     CertificationTypeID
    ) 
    ON DELETE SET NULL 
    NOT DEFERRABLE 
;



ALTER TABLE ProductCountry 
    ADD CONSTRAINT Country_FK02 FOREIGN KEY 
    ( 
     CountryId
    ) 
    REFERENCES Country 
    ( 
     CountryId
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE EnduranceDtl 
    ADD CONSTRAINT EnduranceDetail_Endurance_FK FOREIGN KEY 
    ( 
     EnduranceID
    ) 
    REFERENCES EnduranceHdr 
    ( 
     EnduranceID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE ENDURANCEHDR 
    ADD CONSTRAINT CERTIFICATE_ENDURANCEHDR_FK FOREIGN KEY 
    ( 
     CERTIFICATIONTYPEID,
     CERTIFICATEID
    ) 
    REFERENCES  CERTIFICATE 
    ( 
     CERTIFICATIONTYPEID,
     CERTIFICATEID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE HighSpeedDtl 
    ADD CONSTRAINT HighSpeedDetail_HighSpeed_FK FOREIGN KEY 
    ( 
     HighSpeedID
    ) 
    REFERENCES HighSpeedHdr 
    ( 
     HighSpeedID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE HIGHSPEEDHDR 
    ADD CONSTRAINT HIGHSPEEDHDR_CERTIFICATE_FK FOREIGN KEY 
    ( 
     CERTIFICATIONTYPEID,
     CERTIFICATEID
    ) 
    REFERENCES  CERTIFICATE 
    ( 
     CERTIFICATIONTYPEID,
     CERTIFICATEID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE MeasureDtl 
    ADD CONSTRAINT MeasureDetail_Measure_FK FOREIGN KEY 
    ( 
     MeasureID
    ) 
    REFERENCES MeasureHdr 
    ( 
     MeasureID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE MeasureHdr 
    ADD CONSTRAINT Measure_Certificate_FK FOREIGN KEY 
    ( 
     CertificationTypeID,
     CERTIFICATEID
    ) 
    REFERENCES Certificate 
    ( 
     CertificationTypeID,
     CERTIFICATEID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE Product 
    ADD CONSTRAINT NPRMaster_FK02 FOREIGN KEY 
    ( 
     NprId
    ) 
    REFERENCES NPR_Master 
    ( 
     NprId
    ) 
    ON DELETE SET NULL 
    NOT DEFERRABLE 
;



ALTER TABLE PlungerDtl 
    ADD CONSTRAINT PlungerDetail_Plunger_FK FOREIGN KEY 
    ( 
     PlungerID
    ) 
    REFERENCES PlungerHdr 
    ( 
     PlungerID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE PlungerHdr 
    ADD CONSTRAINT Plunger_Certificate_FK FOREIGN KEY 
    ( 
     CertificationTypeID,
     CERTIFICATEID
    ) 
    REFERENCES Certificate 
    ( 
     CertificationTypeID,
     CERTIFICATEID
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE PRODUCTCERTIFICATE 
    ADD CONSTRAINT ProdCertif_CERTIFICATE_FK FOREIGN KEY 
    ( 
     CERTIFICATIONTYPEID,
     CERTIFICATEID
    ) 
    REFERENCES CERTIFICATE 
    ( 
     CERTIFICATIONTYPEID,
     CERTIFICATEID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE ProductCertificate 
    ADD CONSTRAINT ProdCertif_Product_FK FOREIGN KEY 
    ( 
     SKUID
    ) 
    REFERENCES Product 
    ( 
     SKUID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE ProductCountry 
    ADD CONSTRAINT Product_FK01 FOREIGN KEY 
    ( 
     SKUId
    ) 
    REFERENCES Product 
    ( 
     SKUID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE Country 
    ADD CONSTRAINT Region_FK02 FOREIGN KEY 
    ( 
     RegionId
    ) 
    REFERENCES Region 
    ( 
     RegionId
    ) 
    ON DELETE SET NULL 
    NOT DEFERRABLE 
;



ALTER TABLE BRANDREGION 
    ADD CONSTRAINT Region_ID_FK02 FOREIGN KEY 
    ( 
     RegionId
    ) 
    REFERENCES Region 
    ( 
     RegionId
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;



ALTER TABLE CERTIFICATIONSEARCHTYPE 
    ADD CONSTRAINT SearchType_FK FOREIGN KEY 
    ( 
     TypeID
    ) 
    REFERENCES SearchType 
    ( 
     TypeID
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;



ALTER TABLE SoundDetail 
    ADD CONSTRAINT SoundDetail_SoundHdr_FK FOREIGN KEY 
    ( 
     SoundID
    ) 
    REFERENCES SoundHdr 
    ( 
     SoundID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE SoundHdr 
    ADD CONSTRAINT SoundHdr_Certificate_FK FOREIGN KEY 
    ( 
     CertificationTypeID,
     CERTIFICATEID
    ) 
    REFERENCES Certificate 
    ( 
     CertificationTypeID,
     CERTIFICATEID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE SpeedTestDetail 
    ADD CONSTRAINT SpeedTestDetail_FK01 FOREIGN KEY 
    ( 
     HighSpeedID
    ) 
    REFERENCES HighSpeedHdr 
    ( 
     HighSpeedID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE Product 
    ADD CONSTRAINT TireType_FK03 FOREIGN KEY 
    ( 
     TireTypeId
    ) 
    REFERENCES TireType 
    ( 
     TireTypeId
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE TreadWearDtl 
    ADD CONSTRAINT TreadWearDetail_TreadWear_FK FOREIGN KEY 
    ( 
     TreadWearID
    ) 
    REFERENCES TreadWearHdr 
    ( 
     TreadWearID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE TreadWearHdr 
    ADD CONSTRAINT TreadWear_Certificate_FK FOREIGN KEY 
    ( 
     CertificationTypeID,
     CERTIFICATEID
    ) 
    REFERENCES Certificate 
    ( 
     CertificationTypeID,
     CERTIFICATEID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE WetGripDetail 
    ADD CONSTRAINT WetGripDetail_WetGripHdr_FK FOREIGN KEY 
    ( 
     WetGripID
    ) 
    REFERENCES WetGripHdr 
    ( 
     WetGripID
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE WetGripHdr 
    ADD CONSTRAINT WetGripHdr_Certificate_FK FOREIGN KEY 
    ( 
     CertificationTypeID,
     CERTIFICATEID
    ) 
    REFERENCES Certificate 
    ( 
     CertificationTypeID,
     CERTIFICATEID
    ) 
    NOT DEFERRABLE 
;


CREATE SEQUENCE APP_MESSAGE_SEQ        INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE BeadUnseatID_SEQ       INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE CERTIFICATIONID_SEQ    INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE ChangeLogId_SEQ        INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE COUNTRYID_SEQ          INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE EnduranceID_SEQ        INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE HIghSpeedID_SEQ        INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE MeasureId_SEQ          INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE NPRID_SEQ              INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE PlungerID_SEQ		       INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
--The first 100.000 ids are to be exclusively used to import data to ICS System.
CREATE SEQUENCE SkuID_SEQ			         INCREMENT BY 1 START WITH 100000 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE REGIONID_SEQ           INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE SEARCHTYPEID_SEQ       INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE TreadWearID_SEQ        INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE SoundID_SEQ            INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE WETGRIPID_SEQ          INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;
CREATE SEQUENCE CERTIFICATEID_SEQ      INCREMENT BY 1 START WITH 1 MAXVALUE 999999999999999999 MINVALUE 1 CYCLE NOCACHE ORDER;


Commit;

