Public Interface IQueryView
    Inherits IView

    Event ReloadViewData As CustomEvents.PlainEventHandler

    'Data Sources
    Property GridSource() As DataTable
    Property FilterColumnSource() As List(Of String)
    Property FilterSource() As List(Of String)

    Property ErrorText() As String
End Interface
