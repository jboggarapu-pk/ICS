Imports CooperTire.ICS.Presenter
Imports CooperTire.ICS.DomainEntities

''' <summary>
''' Base control for ICS Certification controls
''' </summary>
''' <remarks></remarks>
Public Class BaseCertificationControl
    Inherits BaseUserControl

End Class
