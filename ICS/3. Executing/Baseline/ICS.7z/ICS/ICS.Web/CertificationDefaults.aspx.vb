Imports System.Xml

Imports CooperTire.ICS.Presenter
Imports CooperTire.ICS.Common

Partial Public Class CertificationDefaults
    Inherits BasePage



End Class